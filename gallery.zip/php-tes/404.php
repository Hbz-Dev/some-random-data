<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>404 Page Not Found</title>
  
  <!-- bootstrap css -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <!-- animate.css -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css"/>
  
  <style>
    body {
      margin: 0;
      padding: 0;
      overflow: hidden;
      background-color: black;
    }
    .error-content {
      text-align: center;
      padding: 200px 0;
      background-color: deepskyblue;
    }

    h1 {
      font-size: 100px;
      color: #f4511e;
      animation: shake 0.5s ease-in-out infinite;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      perspective: 1000px;
    }

    @keyframes shake {
  0% { transform: translate(1px, 1px) rotate(0deg); }
  10% { transform: translate(-1px, -2px) rotate(-1deg); }
  20% { transform: translate(-3px, 0px) rotate(1deg); }
  30% { transform: translate(3px, 2px) rotate(0deg); }
  40% { transform: translate(1px, -1px) rotate(1deg); }
  50% { transform: translate(-1px, 2px) rotate(-1deg); }
  60% { transform: translate(-3px, 1px) rotate(0deg); }
  70% { transform: translate(3px, 1px) rotate(-1deg); }
  80% { transform: translate(-1px, -1px) rotate(1deg); }
  90% { transform: translate(1px, 2px) rotate(0deg); }
  100% { transform: translate(1px, -2px) rotate(-1deg); }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="error-content animate__animated animate__bounceIn">
      <h1>404</h1>
      <h3 class="animate__animated animate__fadeIn">Page Not Found</h3>
      <p class="animate__animated animate__fadeIn">The page you are looking for might have been removed, had its name changed or is temporarily unavailable.</p>
      <a href="/" class="btn btn-secondary animate__animated animate__fadeIn">Go Home</a>
    </div>
  </div>
</body>
</html>
