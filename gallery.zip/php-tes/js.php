<?php
$connect = mysqli_connect("localhost", "root", "300506", "gallery");

//baca file json dari url web
$url = "http://localhost:3000/src/loli-1.json";
$json = file_get_contents('./src/loli-1.json');

// memecah data json per record
$split = explode(",", $json);
$split = json_decode($json,true);
$asu = explode('/', $split[0]);
echo implode(" ", $asu);
echo '<br>';
echo $asu[6];

//for ($i = 0; $i <= split.strlen(); $i++) {
//    $nama = explode('/', $split[i]);
//    $nama = $nama[6];
// sql insert data ke database mysql tabel pegawai2
// $sql = "INSERT INTO images VALUES ('".$id."', '".$nama."', '".$email."', '".$pekerjaan."', '".$alamat."')";
//
// $result = mysqli_query($connect, $sql);
 //}
//
 //echo "Import data berhasil !!";
?>