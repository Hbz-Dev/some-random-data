<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css"/>
    <style>
      .thumbnail {
        padding: 0;
      }
      .thumbnail img {
        width: 100%;
        height: 200px;
        object-fit: cover;
      }
      td {
      text-align: center;
    }

    img {
      width: 200px;
      height: 200px;
      object-fit: cover;
      position: relative;
      opacity: 1;
      transition: opacity 0.5s;
    }
    img:before {
      content: attr(title);
      position: absolute;
      bottom: 10px;
      left: 10px;
      background-color: rgba(0,0,0,0.5);
      color: #fff;
      padding: 5px 10px;
      display: none;
    }
    img:hover:before {
      display: block;
    }
    img:hover {
      opacity: 0.7;
    }
    </style>
  </head>
  <body>
  <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">PHP Image Gallery</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="/">Gallery</a></li>
      <li><a href="/add">Add Image</a></li>
      <li><a href="delete.php">Delete Image</a></li>
    </ul>
   </div>
  </nav>

  <div class="container mt-5">
  <?php
  if (isset($_SESSION['message'])) {
    echo "<div class='alert alert-danger'>" . $_SESSION['message'] . "</div>";
    unset($_SESSION['message']);
  }
  ?>
  <h2>Image Gallery</h2>
  <table class="table">
    <tbody>
      <tr>
        <?php
        $conn = mysqli_connect("localhost", "root", "300506", "gallery");
        $sql = "SELECT * FROM images";
        $result = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_array($result)) {
          echo "<td class='col-4'>
                  <a href='#' data-toggle='modal' data-target='#imageModal" . $row['id'] . "'>
                    <img title= '" . $row['name'] . "'class='animate__animated animate__fadeIn' src='" . $row['path'] . "'>
                  </a>

                  <!-- Modal -->
                  <div class='modal fade' id='imageModal" . $row['id'] . "' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>
                    <div class='modal-dialog' role='document'>
                      <div class='modal-content'>
                        <div class='modal-header'>
                          <h5 class='modal-title' id='exampleModalLabel'>Image</h5>
                          <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                            <span aria-hidden='true'>&times;</span>
                          </button>
                        </div>
                        <div class='modal-body'>
                          <img src='" . $row['path'] . "' style='width: 100%; height: 200px; object-fit: cover;'>
                        </div>
                        <div class='modal-footer'>
                          <a href='" . $row['path'] . "' class='btn btn-primary'>Full</a>
                          <a href='delete.php?id=" . $row['id'] . "' class='btn btn-danger'>
                            <i class='fas fa-trash'></i> Delete
                          </a>
                          <button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </td>";
          if (($row['id'] % 3) == 0) {
            echo "</tr><tr>";
          }
        }
        ?>
      </tr>
    </tbody>
  </table>
</div>
    b4-
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script>
      // Add animation on scroll
      $(window).scroll(function() {
        $(".thumbnail").each(function() {
          var pos = $(this).offset().top;
          var winTop = $(window).scrollTop();
          if (pos < winTop + 600) {
            $(this).addClass("slide");
          }
        });
      });
    </script>
  </body>
</html>
