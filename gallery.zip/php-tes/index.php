<?php
$endpoints = [
  '/' => 'main.php',
  '/add' => 'add.php',
  '/delete' => 'delete.php',
  '/js' => 'js.php',
];

$url = $_SERVER['REQUEST_URI'];

if (array_key_exists($url, $endpoints)) {
  include_once $endpoints[$url];
} else {
  http_response_code(404);
  include_once '404.php';
}
?>