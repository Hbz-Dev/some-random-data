<?php
// Connect to the database
$conn = mysqli_connect("localhost", "root", "300506", "gallery");
include_once('404.php');
// Check if the image ID is set in the URL
if (isset($_GET['id'])) {
  $id = $_GET['id'];
  // Delete the image from the folder
  $sql = "SELECT * FROM images WHERE id=$id";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_array($result);
  $path = $row['path'];
  unlink($path);
  // Delete the image details from the database
  $sql = "DELETE FROM images WHERE id=$id";
  if (mysqli_query($conn, $sql)) {
    $_SESSION['message'] = "Image deleted successfully.";
    header("location: index.php");
  } else {
    $_SESSION['message'] = "Error deleting image.";
    header("location: index.php");
  }
}
// Close the database connection
mysqli_close($conn);
?>
