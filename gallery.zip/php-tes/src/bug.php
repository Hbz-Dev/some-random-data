<?php
$endpoints = [
  '/' => 'index.php',
  '/add' => 'add.php',
  '/delete' => 'delete.php',
];

$url = $_SERVER['REQUEST_URI'];

if (array_key_exists($url, $endpoints)) {
  include $endpoints[$url];
} else {
  http_response_code(404);
  echo '404.php';
}
?>