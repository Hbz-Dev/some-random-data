<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  </head>
  <body>
  <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">PHP Image Gallery</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="/">Gallery</a></li>
      <li><a href="/add">Add Image</a></li>
      <li><a href="delete.php">Delete Image</a></li>
    </ul>
   </div>
  </nav>
    <div class="container">
      <h1>Add Image</h1>
      <hr>
      <form action="add.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
          <label for="name">Name:</label>
          <input type="text" class="form-control" id="name" name="name">
        </div>
        <div class="form-group">
          <label for="description">Description:</label>
          <textarea class="form-control" id="description" name="description"></textarea>
        </div>
        <div class="form-group">
          <label for="image">Image:</label>
          <input type="file" class="form-control" id="image" name="image">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>
      <?php
      // Connect to the database
      $conn = mysqli_connect("localhost", "root", "300506", "gallery");
      // Check if the form is submitted
      if (isset($_POST['name']) && isset($_FILES['image'])) {
        // Get the form data
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $image = $_FILES['image']['name'];
        $target = "images/" . basename($image);
        // Upload the image to the folder
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
          // Insert the image details into the database
          $sql = "INSERT INTO images (name, description, path) VALUES ('$name', '$description', '$target')";
          if (mysqli_query($conn, $sql)) {
            echo "<div class='alert alert-success'>Image added successfully.</div>";
          } else {
            echo "<div class='alert alert-danger'>Error adding image.</div>";
          }
        } else {
          echo "<div class='alert alert-danger'>Error uploading image.</div>";
        }
      }
      // Close the database connection
      mysqli_close($conn);
      ?>
    </div>
  </body>
</html>
