import fetch from "node-fetch";
import { load } from "cheerio";

async function wp(query) {
  let data = await fetch(
    "https://www.peakpx.com/en/search?q=" +
      query +
      "&page=2"
      //Math.floor(Math.random() * (20 - 1 + 1) + 1)
  )
  let resuit = []
  let $ = load(await data.text())
  $("#list_ul > li").each((i, el) => {
    let img = $(el).find("figure > a").find("img").attr("data-src")
    if (!img) return
    resuit.push(img.replace(/-thumbnail/g, ""))
  })
  return resuit
}
wp('loli').then(console.log)