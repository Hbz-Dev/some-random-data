import axios from 'axios'
import uploadFile from '../lib/uploadFile.js'
import { downloadMediaMessage } from '@adiwajshing/baileys'

let handler = async (m, ctx) => {
	let q = m.quoted ? m.quoted : m
	let mime = (q.msg || q).mimetype || q.mediaType || ''
	if (!mime) throw 'No media found'
	let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime)
	let media = await downloadMediaMessage(m.quoted ? await m.getQuotedObj() : m, 'buffer', {}, ctx.conn)

	if (isTele && media.length < 5242880) {
		let data = await uploadFile(conn, media, ctx.args[0] || 'tele')
				let caption = `*Succes Upload !*\n\nMedia Size ${media.length}\nUrl ${data}\n\nCopy Url On Button`
				let link = `https://www.whatsapp.com/otp/copy/${data}`
		await conn.sendHydrated(m.chat, caption, null, null, link, 'Copy', null, null, [], m )
	} else if (/image|video|audio|sticker|document/.test(mime)) {
		let data = await uploadFile(conn, media, ctx.args[0])
				let caption = `*Succes Upload !*\n\nMedia Size ${media.length}\nUrl ${data}\n\nCopy Url On Button`
				let link = `https://www.whatsapp.com/otp/copy/${data}`
		await conn.sendHydrated(m.chat, caption, null, null, link, 'Copy', null, null, [], m )
	}
}
handler.help = ['ToUrl']
handler.tags = ['converted']
handler.command = /^tourl|upload$/i

export default handler