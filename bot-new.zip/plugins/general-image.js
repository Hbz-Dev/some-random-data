import util from 'util'
import _gis from 'g-i-s'
import axios from 'axios'
export let gis = util.promisify(_gis)

let handler = async (m, { conn, text, usedPrefix: _p, command: cmd }) => {
	if (!text) throw 'Input Query'
	let json = await gis(text)
	if (!json.length) throw `Query "${text}" not found`
	let img = json.getRandom().url
	await conn.sendButton(m.chat, `*Result From :* ${text.capitalize()}`, await shortUrl(img), img, [['Next', `${_p}${cmd} ${text}`]], m)
}
handler.tags = ['images']
handler.command = /^image$/i
handler.help = ['Image']

export default handler

function shortUrl(url) {
	return axios.get(`https://tinyurl.com/api-create.php?url=${url}`).then(x => x.data).catch(console.log)
}