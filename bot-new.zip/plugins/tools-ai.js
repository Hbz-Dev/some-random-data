import axios from 'axios'

let handler = async (m, { text }) => {
	if (!text) throw 'Use Command With Some Question'
		let ai = await send(`${text}`)
		await m.reply(ai)
}

handler.command = /^ai$/i
handler.help = ['AI']
handler.tags = ['tools']
export default handler

async function send(msg) {
	let resp = await axios.post('https://api.openai.com/v1/completions', {
		model: 'text-davinci-001',
		prompt: msg,
		temperature: 0.5,
		max_tokens: 1024,
		n: 1
	}, { headers: {
		'Content-Type': 'application/json',
		Authorization: 'Bearer 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'
	}})
	return resp.data.choices[0].text
}