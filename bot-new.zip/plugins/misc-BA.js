import axios from 'axios'
async function fetchJson(url, options) {
  try {
      options ? options : {}
      const res = await axios({
          method: 'GET',
          url: url,
          headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
          },
          ...options
      })
      return res.data
  } catch (err) {
      return err
  }
}
async function handler(m, { args, conn }) {
if (!args[0]) return m.reply('Masukkan nama muridnya!')
let q = args.join(' ').capitalizeV2()
if (/\bshun\s+(kecil|small|kid)\b/i.test(q)) q = 'Shun (Small)'
if (/\bnewyear\b/i.test(q)) q = q.replace(/\bnewyear\b/i, '') + '(New Year)'
if (/\bmaid\b/i.test(q)) q = q.replace(/\bmaid\b/i, '') + '(Maid)'
if (/\bswimsuit\b/i.test(q)) q = q.replace(/\bswimsuit\b/i, '') + '(Swimsuit)'

/* official API (kinda slow)
https://bluearchive.wiki/w/api.php?action=query&titles=File:${q}.png&prop=imageinfo&iilimit=50&iiend=2007-12-31T23:59:59Z&iiprop=timestamp|user|url&format=json
if (thumb.query.pages['-1']) return m.reply('Karakter tidak ditemukan!')
thumb = thumb.query.pages[Object.keys(thumb.query.pages)].imageinfo[0].url

let fullsw = await fetchJson(`https://bluearchive.wiki/w/api.php?action=query&titles=File:${q}_full.png&prop=imageinfo&iilimit=50&iiend=2007-12-31T23:59:59Z&iiprop=timestamp|user|url&format=json`)
let fusll = Object.keys(fullsw.query.pages)
let full = fullsw.query.pages[fusll].imageinfo[0].url
*/

let data = JSON.parse(JSON.stringify(await fetchJson("https://raw.githubusercontent.com/lonqie/SchaleDB/main/data/en/students.json")))
let result = data.find((obj => obj.Name == q));
if (!result) return m.reply('Karakter Tidak Ditemukan!')
let thumb = `https://raw.githubusercontent.com/lonqie/SchaleDB/main/images/student/icon/${result.Id}.webp`

let star = Array.from({ length: result.StarGrade }, () => "⭐").join('')
let eq = result.Equipment.join('-')

let skill = result.Skills.map((skill, index) => {
  return `Skill ${index + 1}${skill.Name ? `: ${skill.Name}` : ''}\n•Type: ${skill.SkillType}\n•Description: ${skill.Desc ? params(skill.Parameters, skill.Desc) : 'Normal Auto Attack'}`;
}).join('\n\n');



let str = `
*Name:* ${result.FamilyName || '-'} ${result.PersonalName || ''}
*Age:* ${result.CharacterAge || '-'}
*School:* ${result.School || '-'}
*Club:* ${result.Club || '-'}
*Star Grade:* ${star || '⭐'}
*Role:* ${result.TacticRole || '-'}
*Position:* ${result.Position || '-'}
*Hobby:* ${result.Hobby || '-'}
*Attact Type:* ${result.BulletType || '-'}
*Armor Type:* ${result.ArmorType || '-'}
*Weapon:* ${result.WeaponType || '-'}
*Birthday:* ${result.BirthDay || '-'}
*Equip:* ${eq || '-'}


${result.ProfileIntroduction || '-'}

${skill || '-'}`


await conn.sendMessage(m.chat, { text: str, contextInfo: { externalAdReply: { title: q, body: '', thumbnailUrl: thumb, sourceUrl: "https://bluearchive.wiki/", mediaType: 1, renderLargerThumbnail: true }}}, { quoted: m })
} 


function params(Parameters, desc) {
  let currentIndex = 1;
return desc.replace(/<\?\d+>/g, match => {
    const value = Parameters.flat().find((_, index) => index === currentIndex - 1);
    currentIndex++;
    return value;
});
}

handler.help = ['ba-info']
handler.tags = ['misc']
handler.command = /^(ba-info|bainfo)$/i

export default handler