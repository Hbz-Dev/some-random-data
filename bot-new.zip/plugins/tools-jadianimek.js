import { v4 } from 'uuid'
import crypto from 'crypto'
import sharp from 'sharp'
import axios from 'axios'
import { SocksProxyAgent } from 'socks-proxy-agent'

let httpsAgent = new SocksProxyAgent(`socks5://60.165.35.64:7302`)
let handler = async (m, { conn, usedPrefix, command }) => {
	let q = m.quoted ? m.quoted : m,
		mime = (q.msg || q).mimetype || q.mediaType || ''
	if (/image/g.test(mime)) {
m.reply('On Progress, Please Wait')
	let toanim = await toAnime(await q.download())
	let img = JSON.parse(toanim.extra).img_urls[1]
	let { data } = await conn.getFile(img)
	data = await crop(data)
	await m.reply(data)
	} else throw `Send/reply an image with command ${usedPrefix + command}`
}

handler.help = ['ToAnime']
handler.tags = ['tools']
handler.command = /^(to|jadi)anime$/i

export default handler

const toAnime = async (buffer) => {
	let obj = {
		busiId: 'different_dimension_me_img_entry',
		extra: JSON.stringify({
			face_rects: [],
			version: 2,
			platform: 'web',
			data_report: {
				parent_trace_id: v4(),
				root_channel: '',
				level: 0
			}
		}),
		images: [buffer.toString('base64')]
	}
	let resp = await axios({
		method: 'POST',
		url: 'https://ai.tu.qq.com/trpc.shadow_cv.ai_processor_cgi.AIProcessorCgi/Process',
		data: obj,
		headers: {
			'Origin': 'https://h5.tu.qq.com',
			'Referer': 'https://h5.tu.qq.com/',
			'x-sign-value': crypto.createHash('md5').update('https://h5.tu.qq.com' + JSON.stringify(obj).length + 'HQ31X02e').digest('hex'),
			'x-sign-version': 'v1',
		},
		httpsAgent
	})
	return resp.data
}

const crop = async (image) => {
	let img = await sharp(image),
		left = 493, top = 0,
		width = 500, height = 752
	return img.extract({ left, top, width, height }).toBuffer()
	}