let handler = async (m, { text }) => {
  let user = global.db.data.users[m.sender]
  user.afk = + new Date
  user.afkReason = text
  m.reply(`
${conn.getName(m.sender)} is now AFK${text ? ': ' + text : ''}
`)
//m.reply(`sock.sendMessage(from, {text: teks, contextInfo:{"externalAdReply": {"title": judul, "body": isi, "mediaType": 3,"thumbnail": fs.readFileSync('./media/yourMedia.jpg')}}}, {sendEphemeral: true, quoted: msg, })`)
}
handler.help = ['afk [alasan]']
handler.tags = ['main']
handler.command = /^afk$/i

export default handler