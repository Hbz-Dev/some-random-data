import yts from 'yt-search'

let handler = async (m, { conn, text, usedPrefix: _p }) => {
	if (!text) throw 'Input Query'
	let res = (await yts(text)).videos 
	if (!res.length) throw `Query "${text}" Not Found`
	let arr = []
	for (let x of res) arr.push(`*${x.title}*\n${x.timestamp}\nUploaded ${x.ago || '-'}\n${parseInt(x.views).toLocaleString()} views\n${x.url}`)
	m.reply(arr.join('\n\n'))
	// await conn.sendMessage(m.chat, { text: `Result From: ${text}`, footer: null, title: null, buttonText: 'Result', sections: [{, { quoted: m })

}
handler.help = ['ytsearch']
handler.tags = ['tools']
handler.command = /^yts(earch)?$/i

export default handler